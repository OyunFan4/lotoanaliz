/** Cautious official-source checker for Netlify. No scraping barriers are bypassed.
 * Result pages can return unrendered templates. Such pages NEVER become verified data.
 */
const HOST='https://www.millipiyangoonline.com';
const GAMES={sayisal:{slug:'sayisal-loto',max:90},super:{slug:'super-loto',max:60}};
const MONTHS={'ocak':1,'şubat':2,'mart':3,'nisan':4,'mayıs':5,'haziran':6,'temmuz':7,'ağustos':8,'eylül':9,'ekim':10,'kasım':11,'aralık':12};
const cache=new Map();
function reply(status, payload) {return new Response(JSON.stringify(payload),{status,headers:{'content-type':'application/json; charset=utf-8','cache-control':'no-store','x-content-type-options':'nosniff'}})}
function decode(s){return s.replace(/&nbsp;|&#160;/gi,' ').replace(/&amp;/gi,'&').replace(/&#(\d+);/g,(_,n)=>String.fromCharCode(Number(n)))}
function plain(s){return decode(s.replace(/<[^>]*>/g,' ').replace(/\s+/g,' ').trim())}
function parse(html,game,year,number,url){
 if (/\{\{\s*(?:#each|this|winningNumber|numberJolly|superstar)/i.test(html)) throw Error('Kaynak işlenmemiş şablon döndürdü');
 // Only accept explicit game title, date, draw ID and clearly separated winning-number elements.
 const g=GAMES[game];const title=html.match(/<h[1-3][^>]*>([\s\S]*?Sonuçları[\s\S]*?)<\/h[1-3]>/i);
 if(!title || !plain(title[1]).toLocaleLowerCase('tr').includes(game==='super'?'süper loto':'sayısal loto'))throw Error('Oyun başlığı doğrulanamadı');
 const dateMatch=plain(title[1]).match(/(\d{1,2})\s+(Ocak|Şubat|Mart|Nisan|Mayıs|Haziran|Temmuz|Ağustos|Eylül|Ekim|Kasım|Aralık)\s+(\d{4})/i);
 if(!dateMatch)throw Error('Tarih doğrulanamadı');
 const month=MONTHS[dateMatch[2].toLocaleLowerCase('tr')];if(Number(dateMatch[3])!==year)throw Error('Yıl uyuşmuyor');
 const drawDate=`${year}-${String(month).padStart(2,'0')}-${String(Number(dateMatch[1])).padStart(2,'0')}`;
 if(!Number.isFinite(Date.parse(drawDate))||new Date(drawDate+'T00:00:00Z')>new Date())throw Error('Tarih geçersiz');
 const numMatch=plain(html).match(/Çekiliş\s*no\s*:\s*(\d+)/i);
 if(!numMatch||Number(numMatch[1])!==number)throw Error('Çekiliş numarası doğrulanamadı');
 // Extract a dedicated winning-numbers section; reject flattened pages and extra candidates.
 const section=html.match(/<h[2-4][^>]*>\s*Kazanan\s+Numaralar\s*<\/h[2-4]>([\s\S]*?)(?=<h[1-4]\b|Kazanan\s+Kategoriler)/i);
 if(!section)throw Error('Kazanan sayılar bölümü bulunamadı');
 const raw=section[1];const candidates=[...raw.matchAll(/<(?:span|li|div|b|strong)[^>]*>\s*(\d{1,2})\s*<\/(?:span|li|div|b|strong)>/gi)].map(m=>Number(m[1]));
 const expected=game==='sayisal'?8:6;
 if(candidates.length!==expected)throw Error(`Ana ve ek sayılar güvenle ayrıştırılamadı (${candidates.length}/${expected})`);
 const nums=candidates.slice(0,6).sort((a,b)=>a-b);
 if(nums.length!==6||new Set(nums).size!==6||nums.some(n=>n<1||n>g.max))throw Error('Sayı kuralları sağlanmadı');
 return {game,date:drawDate,drawNumber:String(number),numbers:nums,status:'official_verified',sourceUrl:url,fetchedAt:new Date().toISOString()};
}
function latestEstimate(now){const jan=new Date(Date.UTC(now.getUTCFullYear(),0,1));return Math.min(160,Math.max(1,Math.floor((now-jan)/86400000*3/7)+3))}
async function getOne(game,year,n){const url=`${HOST}/${GAMES[game].slug}/cekilis-sonuclari.${n}.${year}`;const ctrl=new AbortController();const timer=setTimeout(()=>ctrl.abort(),4500);
 try {const res=await fetch(url,{headers:{'accept':'text/html','user-agent':'LotoAnalizAI-results-check/1.0'},redirect:'manual',signal:ctrl.signal});
 if(res.status!==200)throw Error(`Kaynak HTTP ${res.status}`);const len=Number(res.headers.get('content-length')||0);if(len>2000000)throw Error('Kaynak yanıtı çok büyük');const html=await res.text();if(html.length>2000000)throw Error('Kaynak yanıtı çok büyük');return parse(html,game,year,n,url)}finally{clearTimeout(timer)}}
export default async function handler(request){const url=new URL(request.url);const game=url.searchParams.get('game')||'super';if(!GAMES[game])return reply(400,{status:'error',message:'Geçersiz oyun',results:[]});
 const now=new Date();const year=now.getUTCFullYear();const key=game;const hit=cache.get(key);if(hit&&Date.now()-hit.time<10*60*1000)return reply(200,{...hit.data,cached:true});
 // At most three results per invocation. No automated historical crawling on Netlify.
 const estimate=latestEstimate(now);const targets=[estimate-2,estimate-1,estimate].filter(x=>x>=1);const results=[];const errors=[];
 for(const n of targets){try{results.push(await getOne(game,year,n))}catch(e){errors.push(`Çekiliş ${n}: ${e.message}`);if(/HTTP (403|429)|abort/i.test(e.message))break}}
 const status=results.length?'ok':'unavailable';const message=results.length?`${results.length} resmî sonuç doğrulandı. Tüm geçmiş taranmadı.`:`Doğrulanmış sonuç alınamadı. ${errors[0]||'Kaynak erişilemiyor.'}`;
 const data={status,message,checkedAt:new Date().toISOString(),results,errors,cached:false,historyComplete:false};cache.set(key,{time:Date.now(),data});return reply(200,data)
}
export const _test={parse,latestEstimate};
